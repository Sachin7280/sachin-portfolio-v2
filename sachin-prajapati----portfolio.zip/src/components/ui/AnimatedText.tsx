import React, { useRef } from "react";
import { motion, useScroll, useTransform } from "motion/react";

interface AnimatedTextProps {
  text: string;
  className?: string;
}

function AnimatedCharacter({ char, progress, start, end }: { key?: React.Key, char: string, progress: any, start: number, end: number }) {
  const opacity = useTransform(progress, [start, end], [0.2, 1]);
  return (
    <motion.span style={{ opacity }}>
      {char}
    </motion.span>
  );
}

export function AnimatedText({ text, className = "" }: AnimatedTextProps) {
  const elementRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: elementRef,
    offset: ['start 0.8', 'end 0.2']
  });

  const words = text.split(" ");
  let charIndex = 0;
  const totalChars = text.length;

  return (
    <div ref={elementRef} className={className + " flex flex-wrap justify-center gap-x-[0.25em]"}>
      {words.map((word, wordIndex) => {
        return (
          <span key={wordIndex} className="inline-flex whitespace-nowrap">
            {word.split("").map((char, i) => {
              const start = charIndex / totalChars;
              const end = start + (1 / totalChars);
              charIndex++;
              return (
                <AnimatedCharacter 
                  key={i} 
                  char={char} 
                  progress={scrollYProgress} 
                  start={start} 
                  end={end} 
                />
              );
            })}
          </span>
        );
      })}
    </div>
  );
}
