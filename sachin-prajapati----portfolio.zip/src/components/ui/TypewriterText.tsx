import { motion } from 'motion/react';

interface TypewriterTextProps {
  text: string | string[];
  delay?: number;
  className?: string;
}

export function TypewriterText({ text, delay = 0, className = "" }: TypewriterTextProps) {
  const lines = Array.isArray(text) ? text : [text];
  
  return (
    <div className={className}>
      {lines.map((line, lineIndex) => (
        <div key={lineIndex} className="block">
          {Array.from(line).map((char, charIndex) => (
            <motion.span
              key={`${lineIndex}-${charIndex}`}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{
                duration: 0.05,
                delay: delay + (lineIndex * line.length + charIndex) * 0.04,
                ease: "linear",
              }}
            >
              {char}
            </motion.span>
          ))}
        </div>
      ))}
    </div>
  );
}
