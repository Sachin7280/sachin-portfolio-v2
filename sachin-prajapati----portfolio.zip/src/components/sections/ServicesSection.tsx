import React from 'react';
import { FadeIn } from '../ui/FadeIn';

const services = [
  {
    num: "01",
    name: "Web Development",
    description: "Designing modern, responsive websites and full-stack admin dashboards using HTML, CSS, JS, React, and robust backend systems.",
  },
  {
    num: "02",
    name: "Mobile Apps & Flutter",
    description: "Building cross-platform mobile apps for iOS and Android using Flutter, Dart, and Java with Firebase integrations.",
  },
  {
    num: "03",
    name: "AI SaaS Applications",
    description: "Integrating powerful AI models to build smart tools like image generators, chatbots, resume builders, and voice assistants.",
  },
  {
    num: "04",
    name: "Content Creation",
    description: "Professional video editing (Capcut, VN, Kinemaster), motion graphics, ad creatives, and high-quality YouTube/Instagram Reels.",
  },
  {
    num: "05",
    name: "Backend & SQL",
    description: "Architecting scalable backend environments and managing relational data with SQL for seamless data flow.",
  }
];

export function ServicesSection() {
  return (
    <section id="services" className="bg-[#FFFFFF] text-[#0C0C0C] rounded-t-[40px] sm:rounded-t-[50px] md:rounded-t-[60px] px-5 sm:px-8 md:px-10 py-20 sm:py-24 md:py-32 relative z-20">
      <h2 className="font-black uppercase text-center text-[clamp(3rem,12vw,160px)] leading-none mb-16 sm:mb-20 md:mb-28">
        Services
      </h2>

      <div className="max-w-5xl mx-auto flex flex-col">
        {services.map((item, i) => (
          <FadeIn key={item.num} delay={i * 0.1} y={30} duration={0.6}>
            <div className={`flex flex-col md:flex-row md:items-center gap-4 md:gap-10 py-8 sm:py-10 md:py-12 ${i !== services.length - 1 ? 'border-b border-black/15' : ''}`}>
              <div className="font-black text-[#0C0C0C] text-[clamp(3rem,10vw,140px)] leading-none w-auto md:w-[150px] lg:w-[200px] shrink-0">
                {item.num}
              </div>
              <div className="flex flex-col gap-2 md:gap-4 flex-1">
                <h3 className="font-medium uppercase text-[clamp(1rem,2.2vw,2.1rem)] leading-tight">
                  {item.name}
                </h3>
                <p className="font-light leading-relaxed max-w-2xl text-[clamp(0.85rem,1.6vw,1.25rem)] opacity-60">
                  {item.description}
                </p>
              </div>
            </div>
          </FadeIn>
        ))}
      </div>
    </section>
  );
}
