import React from 'react';
import { FadeIn } from '../ui/FadeIn';
import { AnimatedText } from '../ui/AnimatedText';
import { ContactButton } from '../ui/ContactButton';

export function AboutSection() {
  return (
    <section id="about" className="min-h-screen py-20 px-5 sm:px-8 md:px-10 flex flex-col items-center justify-center relative overflow-hidden bg-[#0C0C0C]">
      
      {/* 4 Decorative Images */}
      <FadeIn delay={0.1} x={-80} duration={0.9} className="absolute top-[4%] left-[1%] sm:left-[2%] md:left-[4%] w-[120px] sm:w-[160px] md:w-[210px] pointer-events-none">
        <img src="https://shrug-person-78902957.figma.site/_components/v2/ebb2b8f25d8e24d5f0a5ca8af4c950de81aa2fd7/moon_icon.11395d36.png" alt="Moon 3D icon" className="w-full h-auto object-contain" />
      </FadeIn>
      
      <FadeIn delay={0.25} x={-80} duration={0.9} className="absolute bottom-[8%] left-[3%] sm:left-[6%] md:left-[10%] w-[100px] sm:w-[140px] md:w-[180px] pointer-events-none">
        <img src="https://shrug-person-78902957.figma.site/_components/v2/ebb2b8f25d8e24d5f0a5ca8af4c950de81aa2fd7/p59_1.4659672e.png" alt="3D object" className="w-full h-auto object-contain" />
      </FadeIn>
      
      <FadeIn delay={0.15} x={80} duration={0.9} className="absolute top-[4%] right-[1%] sm:right-[2%] md:right-[4%] w-[120px] sm:w-[160px] md:w-[210px] pointer-events-none">
        <img src="https://shrug-person-78902957.figma.site/_components/v2/ebb2b8f25d8e24d5f0a5ca8af4c950de81aa2fd7/lego_icon-1.703bb594.png" alt="Lego icon" className="w-full h-auto object-contain" />
      </FadeIn>

      <FadeIn delay={0.3} x={80} duration={0.9} className="absolute bottom-[8%] right-[3%] sm:right-[6%] md:right-[10%] w-[130px] sm:w-[170px] md:w-[220px] pointer-events-none">
        <img src="https://shrug-person-78902957.figma.site/_components/v2/ebb2b8f25d8e24d5f0a5ca8af4c950de81aa2fd7/Group_134-1.2e04f3ce.png" alt="Group icon" className="w-full h-auto object-contain" />
      </FadeIn>

      <FadeIn delay={0} y={40} className="relative z-10 text-center mb-10 sm:mb-14 md:mb-16">
        <h2 className="hero-heading font-black uppercase leading-none tracking-tight text-[clamp(3rem,12vw,160px)]">
          About me
        </h2>
      </FadeIn>

      <div className="relative z-10 flex flex-col items-center gap-16 sm:gap-20 md:gap-24 mb-10">
        <AnimatedText 
          text="I'm a B.Voc Software Development student at IGNTU. Passionate about vibe coding and full-stack development, my goal is to establish a SaaS AI company. I've built 10+ projects, won 1st rank in a district science exhibition, and have experience from the Sindoor High Level Internship and growing YouTube tech channels."
          className="text-[#D7E2EA] font-medium text-center leading-relaxed max-w-[700px] text-[clamp(1rem,2vw,1.35rem)]"
        />
        <div className="flex flex-col sm:flex-row gap-4 items-center">
          <ContactButton />
          <a href="/Sachin_Resume.pdf" download="Sachin_Resume.pdf" className="border border-[#D7E2EA] text-[#D7E2EA] rounded-full px-8 py-3 sm:px-10 sm:py-3.5 uppercase tracking-widest text-xs sm:text-sm font-medium hover:bg-[#D7E2EA]/10 transition-colors">Download Resume</a>
        </div>
      </div>

    </section>
  );
}
