import React, { useEffect, useState, useRef } from 'react';

const gifs = [
  "https://motionsites.ai/assets/hero-space-voyage-preview-eECLH3Yc.gif",
  "https://motionsites.ai/assets/hero-codenest-preview-Cgppc2qV.gif",
  "https://motionsites.ai/assets/hero-vex-ventures-preview-BczMFIiw.gif",
  "https://motionsites.ai/assets/hero-stellar-ai-v2-preview-DjvxjG3C.gif",
  "https://motionsites.ai/assets/hero-asme-preview-B_nGDnTP.gif",
  "https://motionsites.ai/assets/hero-transform-data-preview-Cx5OU29N.gif",
  "https://motionsites.ai/assets/hero-vitara-preview-Cjz2QYyU.gif",
  "https://motionsites.ai/assets/hero-terra-preview-BFjrCr7T.gif",
  "https://motionsites.ai/assets/hero-skyelite-preview-DHaZIgUv.gif",
  "https://motionsites.ai/assets/hero-aethera-preview-DknSlcTa.gif",
  "https://motionsites.ai/assets/hero-designpro-preview-D8c5_een.gif",
  "https://motionsites.ai/assets/hero-stellar-ai-preview-D3HL6bw1.gif",
  "https://motionsites.ai/assets/hero-xportfolio-preview-D4A8maiC.gif",
  "https://motionsites.ai/assets/hero-orbit-web3-preview-BXt4OttD.gif",
  "https://motionsites.ai/assets/hero-nexora-preview-cx5HmUgo.gif",
  "https://motionsites.ai/assets/hero-evr-ventures-preview-DZxeVFEX.gif",
  "https://motionsites.ai/assets/hero-planet-orbit-preview-DWAP8Z1P.gif",
  "https://motionsites.ai/assets/hero-new-era-preview-CocuDUm9.gif",
  "https://motionsites.ai/assets/hero-wealth-preview-B70idl_u.gif",
  "https://motionsites.ai/assets/hero-luminex-preview-CxOP7ce6.gif",
  "https://motionsites.ai/assets/hero-celestia-preview-0yO3jXO8.gif"
];

const row1Images = [...gifs.slice(0, 11), ...gifs.slice(0, 11), ...gifs.slice(0, 11)];
const row2Images = [...gifs.slice(11), ...gifs.slice(11), ...gifs.slice(11)];

export function MarqueeSection() {
  const [scrollOffset, setScrollOffset] = useState(0);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (sectionRef.current) {
        const sectionTop = sectionRef.current.offsetTop;
        const offset = (window.scrollY - sectionTop + window.innerHeight) * 0.3;
        setScrollOffset(offset);
      }
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    // init
    handleScroll();
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <section ref={sectionRef} id="marquee-section" className="bg-[#0C0C0C] pt-24 sm:pt-32 md:pt-40 pb-10 overflow-hidden flex flex-col gap-3 relative z-20">
      <div 
        className="flex gap-3 will-change-transform"
        style={{ transform: `translate3d(${scrollOffset - 200}px, 0, 0)` }}
      >
        {row1Images.map((src, i) => (
          <img key={`${i}-r1`} src={src} loading="lazy" alt="Project preview" className="w-[420px] h-[270px] rounded-2xl object-cover shrink-0 pointer-events-none" />
        ))}
      </div>
      <div 
        className="flex gap-3 will-change-transform"
        style={{ transform: `translate3d(${-(scrollOffset - 200)}px, 0, 0)` }}
      >
        {row2Images.map((src, i) => (
          <img key={`${i}-r2`} src={src} loading="lazy" alt="Project preview" className="w-[420px] h-[270px] rounded-2xl object-cover shrink-0 pointer-events-none" />
        ))}
      </div>
    </section>
  );
}
