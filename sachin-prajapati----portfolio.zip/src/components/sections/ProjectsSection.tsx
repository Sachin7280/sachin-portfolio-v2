import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { LiveProjectButton } from '../ui/LiveProjectButton';

const projects = [
  {
    num: "01",
    cat: "Full Stack",
    name: "Swasth App For Hospitals",
    images: {
      left1: "https://images.unsplash.com/photo-1516549655169-df83a0774514?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      left2: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      right: "https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?ixlib=rb-4.0.3&auto=format&fit=crop&w=1280&q=80"
    }
  },
  {
    num: "02",
    cat: "Mobile App",
    name: "careDose & fithub",
    images: {
      left1: "https://images.unsplash.com/photo-1526506114620-6dc8bbf25514?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      left2: "https://images.unsplash.com/photo-1584308666744-24d5e1cc3843?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      right: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1280&q=80"
    }
  },
  {
    num: "03",
    cat: "AI SaaS",
    name: "Remindify & SpotPark",
    images: {
      left1: "https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      left2: "https://images.unsplash.com/photo-1506521781263-d8422e82f27a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      right: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1280&q=80"
    }
  }
];

function ProjectCard({ project, i, progress, targetScale, range }: any) {
  const scale = useTransform(progress, range, [1, targetScale]);
  
  return (
    <div className="sticky top-24 md:top-32 flex items-center justify-center p-4 max-w-7xl mx-auto w-full" style={{ top: `calc(6rem + ${i * 28}px)` }}>
      <motion.div 
        style={{ scale }} 
        className="w-full h-[85vh] rounded-[40px] sm:rounded-[50px] md:rounded-[60px] border-2 border-[#D7E2EA] bg-[#0C0C0C] p-4 sm:p-6 md:p-8 flex flex-col gap-4 sm:gap-6 md:gap-8 overflow-hidden origin-top"
      >
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 shrink-0">
          <div className="flex items-center gap-4 sm:gap-8">
            <span className="font-black text-[clamp(2.5rem,8vw,5rem)] leading-none text-[#D7E2EA]">{project.num}</span>
            <div className="flex flex-col">
              <span className="text-[#D7E2EA]/60 uppercase tracking-widest text-xs sm:text-sm">{project.cat}</span>
              <h3 className="font-medium uppercase text-[#D7E2EA] text-xl sm:text-2xl md:text-3xl">{project.name}</h3>
            </div>
          </div>
          <LiveProjectButton />
        </div>

        <div className="flex-1 flex flex-row gap-4 sm:gap-6 md:gap-8 overflow-hidden">
          {/* Left Column 40% */}
          <div className="w-[40%] flex flex-col gap-4 sm:gap-6 md:gap-8 shrink-0">
            <img src={project.images.left1} alt={`${project.name} 1`} className="w-full object-cover rounded-[20px] sm:rounded-[30px] md:rounded-[40px]" style={{ height: 'clamp(130px, 16vw, 230px)' }} loading="lazy" />
            <img src={project.images.left2} alt={`${project.name} 2`} className="w-full object-cover rounded-[20px] sm:rounded-[30px] md:rounded-[40px]" style={{ height: 'clamp(160px, 22vw, 340px)' }} loading="lazy" />
          </div>
          {/* Right Column 60% */}
          <div className="w-[60%] flex-1 overflow-hidden rounded-[40px] sm:rounded-[50px] md:rounded-[60px]">
             <img src={project.images.right} alt={`${project.name} 3`} className="w-full h-full object-cover" loading="lazy" />
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export function ProjectsSection() {
  const containerRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', 'end end']
  });

  return (
    <section ref={containerRef} id="projects" className="bg-[#0C0C0C] rounded-t-[40px] sm:rounded-t-[50px] md:rounded-t-[60px] -mt-10 sm:-mt-12 md:-mt-14 z-10 relative py-20 pb-40">
      <h2 className="hero-heading font-black uppercase text-center text-[clamp(3rem,12vw,160px)] leading-none mb-16 sm:mb-20 md:mb-28">
        Project
      </h2>
      
      <div className="flex flex-col" style={{ gap: '50vh' }}>
        {projects.map((p, i) => {
          const targetScale = 1 - ((projects.length - 1 - i) * 0.03);
          const range = [i * 0.33, 1];
          return (
            <ProjectCard 
              key={i} 
              i={i} 
              project={p} 
              progress={scrollYProgress} 
              targetScale={targetScale} 
              range={range} 
            />
          );
        })}
      </div>
    </section>
  );
}
