import React, { useState } from 'react';
import { FadeIn } from '../ui/FadeIn';
import { ContactButton } from '../ui/ContactButton';
import { Magnet } from '../ui/Magnet';
import { Menu, X } from 'lucide-react';
import { TypewriterText } from '../ui/TypewriterText';

export function HeroSection() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <section className="min-h-screen h-screen flex flex-col overflow-x-clip relative">
      <div className="fixed top-0 left-0 w-full pt-6 md:pt-8 px-4 flex justify-center z-[100]">
        <FadeIn delay={0} y={-20} as="nav" className="flex flex-row justify-between items-center text-[#D7E2EA] font-semibold uppercase tracking-[0.15em] text-[11px] sm:text-xs md:text-sm px-6 py-4 sm:px-12 sm:py-5 w-full max-w-4xl rounded-full backdrop-blur-xl bg-white/5 border border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.3)]">
          <div className="flex items-center justify-between w-full md:w-auto">
            <a href="#about" className="hover:text-white hover:shadow-[0_0_10px_rgba(255,255,255,0.3)] transition-all duration-300 rounded-md px-2 md:hidden">About</a>
            <button 
              className="md:hidden ml-auto text-white p-1"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
          
          <div className={`absolute top-[4rem] sm:top-[4.5rem] left-0 w-full bg-[#111]/95 md:bg-transparent backdrop-blur-xl md:backdrop-blur-none border border-white/10 md:border-none rounded-2xl md:rounded-none flex-col md:flex-row items-center justify-center p-6 md:p-0 gap-6 md:gap-0 ${isMenuOpen ? 'flex' : 'hidden'} md:flex md:static transition-all duration-300 md:w-full md:justify-between`}>
            <a href="#about" onClick={() => setIsMenuOpen(false)} className="hover:text-white hover:shadow-[0_0_10px_rgba(255,255,255,0.3)] transition-all duration-300 rounded-md px-2 hidden md:block">About</a>
            <a href="#projects" onClick={() => setIsMenuOpen(false)} className="hover:text-white hover:shadow-[0_0_10px_rgba(255,255,255,0.3)] transition-all duration-300 rounded-md px-2">Projects</a>
            <a href="https://github.com/Sachin7280" onClick={() => setIsMenuOpen(false)} target="_blank" rel="noreferrer" className="hover:text-white hover:shadow-[0_0_10px_rgba(255,255,255,0.3)] transition-all duration-300 rounded-md px-2">GitHub</a>
            <a href="https://www.linkedin.com/in/letssachin/" onClick={() => setIsMenuOpen(false)} target="_blank" rel="noreferrer" className="hover:text-white hover:shadow-[0_0_10px_rgba(255,255,255,0.3)] transition-all duration-300 rounded-md px-2">LinkedIn</a>
            <a href="#contact" onClick={() => setIsMenuOpen(false)} className="hover:text-white hover:shadow-[0_0_10px_rgba(255,255,255,0.3)] transition-all duration-300 rounded-md px-2">Contact</a>
          </div>
        </FadeIn>
      </div>

      <div className="flex-1 flex flex-col justify-end">
        <div className="overflow-hidden relative z-20">
          <FadeIn delay={0.15} y={40}>
            <h1 className="hero-heading font-black uppercase tracking-tight leading-none whitespace-nowrap w-full text-center text-[13vw] sm:text-[11vw] md:text-[9vw] lg:text-[7.5vw] xl:text-[7vw] mt-6 sm:mt-4 md:-mt-5">
              Hi, i&apos;m sachin
            </h1>
          </FadeIn>
        </div>

        <div className="flex justify-between items-end pb-7 sm:pb-8 md:pb-10 px-6 md:px-10 relative z-20">
          <FadeIn delay={0.35} y={20}>
            <TypewriterText 
              text={[
                "Full Stack & App Developer.",
                "Building AI SaaS and Unforgettable Digital Experiences."
              ]}
              delay={0.6}
              className="text-[#D7E2EA] font-medium tracking-wider leading-relaxed text-[clamp(0.85rem,1.5vw,1.2rem)] max-w-[280px] sm:max-w-[360px] md:max-w-[420px] drop-shadow-md"
            />
          </FadeIn>
          <FadeIn delay={0.5} y={20}>
            <ContactButton />
          </FadeIn>
        </div>
      </div>

      <FadeIn delay={0.6} y={30} className="absolute left-1/2 -translate-x-1/2 z-10 w-[280px] sm:w-[360px] md:w-[440px] lg:w-[520px] top-1/2 -translate-y-1/2 sm:top-auto sm:translate-y-0 sm:bottom-0">
        <Magnet padding={150} strength={3} activeTransition="transform 0.3s ease-out" inactiveTransition="transform 0.6s ease-in-out">
          <img src="https://shrug-person-78902957.figma.site/_components/v2/d24c01ad3a56fc65e942a1f501eb73db42d7cf9a/Rectangle_40443.81459862.png" alt="Hero Portrait" className="w-full h-auto object-cover" />
        </Magnet>
      </FadeIn>
    </section>
  );
}
