import React from 'react';
import { FadeIn } from '../ui/FadeIn';

export function ContactSection() {
  return (
    <section id="contact" className="bg-[#0C0C0C] px-5 sm:px-8 md:px-10 py-24 sm:py-32 relative z-20 overflow-hidden text-[#D7E2EA]">
      <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-12 sm:gap-20">
        
        <div className="flex flex-col gap-6 sm:gap-8">
          <FadeIn y={30} delay={0.1}>
            <h2 className="hero-heading font-black uppercase text-[clamp(2.5rem,8vw,5rem)] leading-none mb-4">Let's Connect</h2>
            <p className="font-light text-lg opacity-80 mb-8 max-w-sm">I'm always open to discussing new projects, creative ideas, or opportunities to be part of your visions.</p>
            
            <div className="flex flex-col gap-4 text-sm sm:text-base font-medium">
              <a href="mailto:mrsachin131156@gmail.com" className="hover:opacity-60 transition-opacity">Email: mrsachin131156@gmail.com</a>
              <a href="tel:7858981037" className="hover:opacity-60 transition-opacity">Phone & WhatsApp: 7858981037</a>
              <a href="https://www.linkedin.com/in/letssachin/" target="_blank" rel="noreferrer" className="hover:opacity-60 transition-opacity flex items-center gap-2">LinkedIn: letssachin</a>
              <a href="https://github.com/Sachin7280" target="_blank" rel="noreferrer" className="hover:opacity-60 transition-opacity flex items-center gap-2">GitHub: Sachin7280</a>
            </div>
          </FadeIn>
        </div>

        <FadeIn y={30} delay={0.2} className="bg-white/5 border border-white/10 rounded-3xl p-6 sm:p-10 backdrop-blur-sm">
          <form className="flex flex-col gap-6" onSubmit={(e) => e.preventDefault()}>
            <div className="flex flex-col gap-2">
              <label htmlFor="name" className="text-sm uppercase tracking-widest opacity-60">Name</label>
              <input type="text" id="name" placeholder="Rahul Kumar" className="bg-transparent border-b border-white/20 py-2 focus:outline-none focus:border-white transition-colors" />
            </div>
            <div className="flex flex-col gap-2">
              <label htmlFor="email" className="text-sm uppercase tracking-widest opacity-60">Email</label>
              <input type="email" id="email" placeholder="youremail@gmail.com" className="bg-transparent border-b border-white/20 py-2 focus:outline-none focus:border-white transition-colors" />
            </div>
            <div className="flex flex-col gap-2">
              <label htmlFor="message" className="text-sm uppercase tracking-widest opacity-60">Message</label>
              <textarea id="message" rows={4} placeholder="Hello Sachin..." className="bg-transparent border-b border-white/20 py-2 focus:outline-none focus:border-white transition-colors resize-none"></textarea>
            </div>
            <button className="mt-4 rounded-full bg-white text-[#0C0C0C] font-black uppercase tracking-widest py-4 hover:bg-white/80 transition-colors">
              Send Message
            </button>
          </form>
        </FadeIn>

      </div>
    </section>
  );
}
